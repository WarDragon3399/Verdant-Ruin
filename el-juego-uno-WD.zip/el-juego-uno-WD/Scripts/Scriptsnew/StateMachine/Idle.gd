class_name IdleState
extends BaseState

func enter():
	controller.sprite.play("Idle")

func physics_update(delta):
	controller.locomotion.move(Vector2.ZERO)
	# Move
	if controller.input_direction != Vector2.ZERO:
		if controller.is_running:
				state_machine.change_state("Run")
		else:
				state_machine.change_state("Move")		 
