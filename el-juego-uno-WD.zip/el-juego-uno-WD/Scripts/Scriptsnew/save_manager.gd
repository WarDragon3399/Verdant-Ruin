extends Node

const SAVE_PATH := "user://savegame.tres"

func save_game():
	var save_data := SaveData.new()
	save_data.inventory = Inventory.items.duplicate(true)
	ResourceSaver.save(save_data, SAVE_PATH)
	print("Game Saved")

func load_game():
	print("LOAD START")
	if !FileAccess.file_exists(SAVE_PATH):
		return
	var save_data = ResourceLoader.load(SAVE_PATH)
	print("RESOURCE LOADED")
	Inventory.items = save_data.inventory
	print("INVENTORY ASSIGNED")	
	print("GAME LOADED")
