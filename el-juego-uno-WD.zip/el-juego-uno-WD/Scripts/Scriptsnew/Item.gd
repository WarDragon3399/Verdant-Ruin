extends Resource
class_name Item

@export var item_sprite : Texture2D
@export var item_id: String
@export var item_name: String
@export var stackable := true

			
