extends Node2D

@onready var ground_layer : TileMapLayer = $GroundLayer
@onready var structure_layer : TileMapLayer = $GroundLayer/StructureLayer
@onready var resource_layer : TileMapLayer = $GroundLayer/DecorationLayer

# =====================
# CONFIGURACIÓN
# =====================

const CHUNK_SIZE := 20

const WORLD_CHUNKS_X := 60
const WORLD_CHUNKS_Y := 60

const CAVE_CHANCE := 0.15

# =====================
# SOURCE IDS
# =====================

const CAVE_SOURCE := 0
const BIOME_SOURCE := 1
const STONE_SOURCE := 2
const MINERAL_SOURCE := 3

# =====================
# BIOMAS
# =====================

const PRAIRIE := Vector2i(0,0)

const FOREST_A := Vector2i(1,0)
const FOREST_B := Vector2i(2,0)

const JUNGLE := Vector2i(3,0)

const WATER := Vector2i(5,0)

const DESERT := Vector2i(1,1)

const MOUNTAIN := Vector2i(3,1)

const SNOW := Vector2i(4,5)

# =====================
# ESTRUCTURAS
# =====================

const CAVE_ENTRANCE := Vector2i(0,0)

# =====================
# MINERALES
# =====================

const NONE := -1

const COAL := 0
const IRON := 1
const GOLD := 2
const CRYSTAL := 3

# CAMBIA ESTAS COORDENADAS
# SEGÚN TU ATLAS DE MINERALES

const COAL_TILE := Vector2i(0,0)
const IRON_TILE := Vector2i(1,0)
const GOLD_TILE := Vector2i(2,0)
const CRYSTAL_TILE := Vector2i(3,0)

# =====================
# DATOS DEL MUNDO
# =====================

var world_data = {}

# =====================
# RUIDOS
# =====================

var terrain_noise : FastNoiseLite
var moisture_noise : FastNoiseLite
var temperature_noise : FastNoiseLite
var cave_noise : FastNoiseLite
var mineral_noise : FastNoiseLite

func _ready():

	randomize()

	setup_noise()

	generate_world()


func setup_noise():

	terrain_noise = FastNoiseLite.new()
	terrain_noise.seed = randi()
	terrain_noise.frequency = 0.003

	moisture_noise = FastNoiseLite.new()
	moisture_noise.seed = randi()
	moisture_noise.frequency = 0.008

	temperature_noise = FastNoiseLite.new()
	temperature_noise.seed = randi()
	temperature_noise.frequency = 0.01

	cave_noise = FastNoiseLite.new()
	cave_noise.seed = randi()
	cave_noise.frequency = 0.02

	mineral_noise = FastNoiseLite.new()
	mineral_noise.seed = randi()
	mineral_noise.frequency = 0.04


func generate_world():

	ground_layer.clear()
	structure_layer.clear()
	resource_layer.clear()

	world_data.clear()

	for chunk_x in range(WORLD_CHUNKS_X):

		for chunk_y in range(WORLD_CHUNKS_Y):

			generate_chunk(
				chunk_x,
				chunk_y
			)


func generate_chunk(
	chunk_x:int,
	chunk_y:int
):

	var start_x = chunk_x * CHUNK_SIZE
	var start_y = chunk_y * CHUNK_SIZE

	for local_x in range(CHUNK_SIZE):

		for local_y in range(CHUNK_SIZE):

			var world_x = start_x + local_x
			var world_y = start_y + local_y

			generate_tile(
				world_x,
				world_y
			)


func generate_tile(
	x:int,
	y:int
):

	var pos = Vector2i(x,y)

	var biome = get_biome(x,y)

	ground_layer.set_cell(
		pos,
		BIOME_SOURCE,
		biome
	)

	var cave = has_cave(x,y)

	if cave:

		structure_layer.set_cell(
			pos,
			CAVE_SOURCE,
			CAVE_ENTRANCE
		)

	var mineral = get_mineral(x,y)

	if mineral != NONE:

		resource_layer.set_cell(
			pos,
			MINERAL_SOURCE,
			mineral_to_tile(mineral)
		)

	world_data[pos] = {
		"cave": cave,
		"cave_seed": hash(str(pos)),
		"mineral": mineral
	}


func get_height(
	x:int,
	y:int
) -> float:

	var noise_value = terrain_noise.get_noise_2d(x,y)

	var map_width = WORLD_CHUNKS_X * CHUNK_SIZE
	var map_height = WORLD_CHUNKS_Y * CHUNK_SIZE

	var center = Vector2(
		map_width * 0.5,
		map_height * 0.5
	)

	var distance = Vector2(x,y).distance_to(center)

	var max_distance = min(
		map_width,
		map_height
	) * 0.5

	var falloff = distance / max_distance

	return noise_value - (falloff * 0.8)


func get_biome(
	x:int,
	y:int
) -> Vector2i:

	var height = get_height(x,y)

	var moisture = moisture_noise.get_noise_2d(x,y)

	var temperature = temperature_noise.get_noise_2d(x,y)

	if height < -0.25:
		return WATER

	if height > 0.50:
		return MOUNTAIN

	if temperature < -0.45:
		return SNOW

	if moisture < -0.35 and temperature > 0.15:
		return DESERT

	if moisture > 0.45:
		return JUNGLE

	if moisture > 0.10:

		if randf() < 0.5:
			return FOREST_A

		return FOREST_B

	return PRAIRIE


func has_cave(
	x:int,
	y:int
) -> bool:

	var height = get_height(x,y)

	if height < 0.55:
		return false

	var value = cave_noise.get_noise_2d(x,y)

	return value > (1.0 - CAVE_CHANCE)


func get_mineral(
	x:int,
	y:int
) -> int:

	var height = get_height(x,y)

	if height < 0.45:
		return NONE

	var value = mineral_noise.get_noise_2d(x,y)

	if value < -0.45:
		return COAL

	if value < -0.15:
		return IRON

	if value < 0.30:
		return GOLD

	return CRYSTAL


func mineral_to_tile(
	mineral:int
) -> Vector2i:

	match mineral:

		COAL:
			return COAL_TILE

		IRON:
			return IRON_TILE

		GOLD:
			return GOLD_TILE

		CRYSTAL:
			return CRYSTAL_TILE

	return COAL_TILE


func is_cave_entrance(pos:Vector2i) -> bool:

	if not world_data.has(pos):
		return false

	return world_data[pos]["cave"]


func get_cave_seed(pos:Vector2i) -> int:

	if not world_data.has(pos):
		return 0

	return world_data[pos]["cave_seed"]
