extends Area2D

@export var item_data: Item
@export var amount := 1

var player_near := false

func _ready():
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body):
	if body.is_in_group("Player"):
		print("Detected:", body.name)
		player_near = true

func _on_body_exited(body):
	if body.is_in_group("Player"):
		print("Left:", body.name)
		player_near = false

func _process(_delta):
	if player_near and Input.is_action_just_pressed("Interact"):
		Inventory.add_item(item_data, amount)
		get_parent().queue_free()
