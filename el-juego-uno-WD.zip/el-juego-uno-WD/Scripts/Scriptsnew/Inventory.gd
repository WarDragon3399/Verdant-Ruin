extends Node

var items := {}

func add_item(item: Item, amount := 1):
	if items.has(item.item_id):
		items[item.item_id] += amount
	else:
		items[item.item_id] = amount

	print("Added ", item.item_name)

func get_amount(item: Item) -> int:
	return items.get(item, 0)
