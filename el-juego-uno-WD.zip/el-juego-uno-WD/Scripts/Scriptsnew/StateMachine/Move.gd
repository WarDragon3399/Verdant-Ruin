class_name MoveState
extends BaseState

func enter():
	pass # Managed in physics update

func physics_update(delta):
	controller.locomotion.move(controller.input_direction)

	# Constantly update animation to catch facing direction changes
	controller.update_animation("Move")

	# Transitions
	if controller.input_direction == Vector2.ZERO:
		state_machine.change_state("Idle")
	elif controller.is_running:
		state_machine.change_state("Run")
	
