# Verdant Ruin

🇬🇧 English:
A 2D pixelart top-down survival, automatization and optimazation game inspired by Dwarf Fortress and Factorio.

🇵🇱 Polish:
Gra 2D, pixelart, top-down, survival z automatyzacją i optymatyzacją inspirowana przez Dward Fortress i Factorio.

🇪🇸 Spanish:
Un juego de supervivencia, automatización y optimización en 2D con gráficos pixelados y vista cenital, inspirado en Dwarf Fortress y Factorio.
