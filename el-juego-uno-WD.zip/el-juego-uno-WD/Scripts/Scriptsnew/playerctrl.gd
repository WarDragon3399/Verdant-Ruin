# Player controller for Comffy Summer jam 2026
# Written by Wardragon3399, Rikata  
extends CharacterBody2D

@export var walk_speed := 10.0
@export var run_speed := 20.0

var locomotion := PlayerLocomotion.new()
var state_machine := StateMachine.new()
var is_running := false
var mobile_run_toggle := false

var input_direction := Vector2.ZERO
var facing_direction := Vector2.DOWN

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var canvas_layer: CanvasLayer = $CanvasLayer


func _ready():
	
	# for map editting 
	canvas_layer.visible = true
	
	# Inject the player reference into locomotion
	locomotion.player = self
	state_machine.controller = self
	# Register states
	state_machine.add_state(
		"Idle",
		IdleState.new()
	)
	state_machine.add_state(
		"Move",
		MoveState.new()
	)
	state_machine.add_state(
		"Run", 
		RunState.new()
	)
		# Initial state
	state_machine.change_state("Idle")		

func _physics_process(_delta):
	var move_direction = Vector2.ZERO
	# Keyboard
	var keyboard_run = Input.is_action_pressed("Run")
	
	# Final run state
	is_running = (keyboard_run or mobile_run_toggle)
	
	if Input.is_action_pressed("Move_Right"):
		move_direction.x = 1
	elif Input.is_action_pressed("Move_Left"):
		move_direction.x = -1
	elif Input.is_action_pressed("Move_Backward"):
		move_direction.y = 1
	elif Input.is_action_pressed("Move_Forward"):
		move_direction.y = -1
			
	input_direction = move_direction.normalized()		
			
	# Update facing direction ONLY when actively pressing a key
	if input_direction != Vector2.ZERO:
		facing_direction = input_direction
		
	#var move_speed
	#if is_running:
	#	move_speed = run_speed
	#else:
	#	move_speed = walk_speed	
		
	#velocity = move_direction * move_speed
	state_machine.physics_update(_delta)
	
	if Input.is_action_just_released("Inventory"):
		for item_id in Inventory.items:
			print(item_id, ": ", Inventory.items[item_id])
		
	if Input.is_action_just_pressed("Save"):
		SaveManager.save_game()

	if Input.is_action_just_pressed("Load"):
		SaveManager.load_game()		
	
	# Animation Helper for the States to call
func update_animation(state_prefix: String) -> void:
	var anim_suffix = ""
	match facing_direction:
		Vector2.DOWN:
			anim_suffix = "_Down"
			sprite.flip_h = false
		Vector2.UP:
			anim_suffix = "_Up"
			sprite.flip_h = false
		Vector2.RIGHT:
			anim_suffix = "_Side"
			sprite.flip_h = false
		Vector2.LEFT:
			anim_suffix = "_Side"
			sprite.flip_h = true
			
	sprite.play(state_prefix + anim_suffix)	



#testing A button probably going to remove it later
@onready var a: Button = $CanvasLayer/AspectRatioContainer/GridContainer/A
@onready var testtext: Panel = $CanvasLayer/AspectRatioContainer/GridContainer/Panel2


func _on_a_mouse_entered() -> void: 
	#hover trigers button press this is good for d pad but im testing on a button
	#If i remember correctly normal button works on phone on web build instead of using touchscreen
	print("hover")
	a.button_pressed = true
	testtext.modulate = ("blue")

func _on_a_pressed() -> void:
	print("pressed")
	testtext.modulate = ("yellow")

func _on_a_mouse_exited() -> void: 
	a.button_pressed = false
	testtext.modulate = ("green")
