class_name RunState
extends BaseState

func enter():
	controller.sprite.play("Run")

func physics_update(delta):
	controller.locomotion.move(controller.input_direction)

	# Transitions
	if controller.input_direction == Vector2.ZERO:
		state_machine.change_state("Idle")
	elif !controller.is_running:
		state_machine.change_state("Move")
