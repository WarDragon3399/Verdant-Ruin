extends Camera2D

# *************************************************************************************
# Camera panning script by Lucas Pawprint (Lucas9348)
# * Pan with left click and zoom with scroll wheel
# * Camera position and zoom are both interpolated
# * Camera can zoom toward mouse
# * Camera control can be enabled and disabled as needed via camera_unlocked
# *************************************************************************************

# Enable and disable panning as needed
@export var camera_unlocked: bool = true:
	set(value):
		camera_unlocked = value
		if value == false:
			# Interupt panning
			stop_panning()
# Zoom the camera to the point the mouse is hovering over.
@export var zoom_toward_mouse: bool = true
@export var POSITION_INTERPOLATION: float = 0.5
@export var ZOOM_INTERPOLATION: float = 0.5

# Mouse position the moment panning starts (viewport-based)
var mouse_pos_on_pan_start: Vector2 = Vector2.ZERO
# Camera position the moment panning starts (global-based)
var cam_pos_on_pan_start: Vector2 = Vector2.ZERO
# Generic boolean for handling panning in process
var is_panning: bool = false



# Lerped values for zooming and positioning.
@onready var target_zoom: float = zoom.x
@onready var target_pos: Vector2 = global_position

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				start_panning()
			else:
				stop_panning()
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			if event.pressed:
				change_zoom(1.2)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			if event.pressed:
				change_zoom(1.0 / 1.2)

func change_zoom(multiplier: float = 1.2) -> void:
	if not camera_unlocked: return
	print("zoom")
	target_zoom = target_zoom * multiplier
	if zoom_toward_mouse:
		var mouse_gpos: Vector2 = get_global_mouse_position()
		var cam_to_mouse_vector: Vector2 = mouse_gpos - target_pos
		var reciprocal_zoom: float = (1.0 - (1.0 / multiplier))
		target_pos += (cam_to_mouse_vector) * reciprocal_zoom
		print("zoom: %s" % target_zoom)

# Set starting vectors and set is_panning to true
func start_panning() -> void:
	if not camera_unlocked: return
	print("camera pan started")
	mouse_pos_on_pan_start = get_viewport().get_mouse_position()
	cam_pos_on_pan_start = global_position
	is_panning = true

func stop_panning() -> void:
	print("camera pan ended")
	is_panning = false

func _process(_delta: float) -> void:
	if is_panning:
		var mouse_offset: Vector2 = mouse_pos_on_pan_start - get_viewport().get_mouse_position()
		var scaled_offset: Vector2 = mouse_offset / target_zoom
		target_pos = cam_pos_on_pan_start + scaled_offset
	zoom = lerp(zoom, Vector2(target_zoom, target_zoom), ZOOM_INTERPOLATION)
	global_position = lerp(global_position, target_pos, POSITION_INTERPOLATION)


#
