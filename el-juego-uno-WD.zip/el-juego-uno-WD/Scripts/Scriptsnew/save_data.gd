extends Resource
class_name SaveData

@export var inventory : Dictionary = {}
@export var player_position : Vector2 = Vector2.ZERO
@export var collected_items : Array[String] = []
#@export var world_time : float = 0.0
#@export var player_level : int = 1
#@export var player_gold : int = 0
