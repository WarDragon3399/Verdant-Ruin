class_name PanningCamera2D
extends Camera2D
## Camera panning script by Lucas Pawprint (Lucas9348)
## 
## Left click to pan. Scroll wheel to zoom.
## Both camera position and zoom are interpolated. Set interpolation values to 1 for instant.
## Includes zoom toward mouse functionality.
##
## Camera control can be enabled and disabled as needed via camera_unlocked

## Enable/disable camera control
@export var camera_unlocked: bool = true:
	set(value):
		camera_unlocked = value
		if value == false: stop_panning()

## When zooming, zoom toward the mouse pointer. (when [code]false[/code], camera zooms into the center of the screen)
@export var zoom_toward_mouse: bool = true

@export_group("Zoom Range")

## [member target_zoom] won't go below this value
## (but may not reach it since the zoom value is
## being multiplied by [member zoom_step] each time you zoom in or out)
@export_range(0, 1, 0.05) var zoom_min: float = 0.3

## [member target_zoom] won't go above this value
## (but may not reach it since the zoom value is
## being multiplied by [member zoom_step] each time you zoom in or out)
@export_range(0, 10, 0.05) var zoom_max: float = 5.0

## Multiply [member target_zoom] by this value when scrolling up or down
@export var zoom_step: float = 1.2

@export_group("Interpolation")

## The interpolation value for camera position, from 0 to 1
@export_range(0, 1) var position_interpolation: float = 0.5

## The interpolation value for camera zoom, from 0 to 1
@export_range(0, 1) var zoom_interpolation: float = 0.5



## Target position for interpolating the camera.
@onready var target_pos: Vector2 = global_position

## Interpolate zoom to this value by zoom_interpolation for zooming and positioning.
@onready var target_zoom: float = zoom.x

## Mouse position the moment panning starts (viewport-based)
var mouse_pos_on_pan_start: Vector2 = Vector2.ZERO

## Camera position the moment panning starts (global-based)
var cam_pos_on_pan_start: Vector2 = Vector2.ZERO

## Generic boolean for handling panning in process
var is_panning: bool = false

## Handles camera input
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				start_panning()
			else:
				stop_panning()
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			if event.pressed:
				change_zoom(1.2)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			if event.pressed:
				change_zoom(1.0 / 1.2)

## Multiply zoom by the given parameter value.
func change_zoom(multiplier: float = 1.2) -> void:
	if not camera_unlocked: return
	
	var new_zoom_value: float = target_zoom * multiplier
	
	if ((new_zoom_value > zoom_max) and (not zoom_max == 0.0)) \
	or ((new_zoom_value < zoom_min) and (not zoom_min == 0.0)):
		return
	
	target_zoom = new_zoom_value
	print("zoom set to: %s" % target_zoom)
	
	if zoom_toward_mouse:
		var mouse_gpos: Vector2 = get_global_mouse_position()
		var cam_to_mouse_vector: Vector2 = mouse_gpos - target_pos
		var reciprocal_zoom: float = (1.0 - (1.0 / multiplier))
		target_pos += (cam_to_mouse_vector) * reciprocal_zoom

## Set starting vectors and set is_panning to true
func start_panning() -> void:
	if not camera_unlocked: return
	print("camera pan started")
	mouse_pos_on_pan_start = get_viewport().get_mouse_position()
	cam_pos_on_pan_start = global_position
	is_panning = true
## Sets [member is_panning] to [code]false[/code]
func stop_panning() -> void:
	print("camera pan ended")
	is_panning = false

func _process(_delta: float) -> void:
	if is_panning:
		var mouse_offset: Vector2 = mouse_pos_on_pan_start - get_viewport().get_mouse_position()
		var scaled_offset: Vector2 = mouse_offset / target_zoom
		target_pos = cam_pos_on_pan_start + scaled_offset
	zoom = lerp(zoom, Vector2(target_zoom, target_zoom), zoom_interpolation)
	global_position = lerp(global_position, target_pos, position_interpolation)
