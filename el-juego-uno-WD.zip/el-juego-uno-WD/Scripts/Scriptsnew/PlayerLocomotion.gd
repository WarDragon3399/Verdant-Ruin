#This is for Commy SUmmer Jam Written by Wardragon3399 & Rikata
#It's player motions handle inputs of game

class_name PlayerLocomotion

var player

func move(direction):
	var speed = player.walk_speed
	if player.is_running:
		speed = player.run_speed
	player.velocity = (direction * speed)
	player.move_and_slide()
